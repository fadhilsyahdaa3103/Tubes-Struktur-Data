#include "Organisasi.h"

Organisasi::Organisasi() {
    root = NULL;
}

Node* Organisasi::cariNode(Node* node, string jabatan) {
    if (node == NULL)
        return NULL;

    if (node->jabatan == jabatan)
        return node;

    Node* hasil = cariNode(node->firstChild, jabatan);
    if (hasil != NULL)
        return hasil;

    return cariNode(node->nextSibling, jabatan);
}

void Organisasi::tambahJabatan(string parentJabatan, string jabatanBaru) {
    Node* nodeBaru = new Node;
    nodeBaru->jabatan = jabatanBaru;
    nodeBaru->firstChild = NULL;
    nodeBaru->nextSibling = NULL;
    nodeBaru->parent = NULL;

    // Jika root belum ada
    if (root == NULL) {
        root = nodeBaru;
        cout << "Root berhasil dibuat.\n";
        return;
    }

    Node* parent = cariNode(root, parentJabatan);
    if (parent == NULL) {
        cout << "Parent tidak ditemukan!\n";
        delete nodeBaru;
        return;
    }

    nodeBaru->parent = parent;

    if (parent->firstChild == NULL) {
        parent->firstChild = nodeBaru;
    } else {
        Node* temp = parent->firstChild;
        while (temp->nextSibling != NULL) {
            temp = temp->nextSibling;
        }
        temp->nextSibling = nodeBaru;
    }

    cout << "Jabatan berhasil ditambahkan.\n";
}

void Organisasi::tampilkan(Node* node, int level) {
    if (node == NULL)
        return;

    for (int i = 0; i < level; i++)
        cout << "  ";

    cout << node->jabatan << endl;

    tampilkan(node->firstChild, level + 1);
    tampilkan(node->nextSibling, level);
}

void Organisasi::tampilStruktur() {
    if (root == NULL) {
        cout << "Struktur organisasi masih kosong.\n";
        return;
    }
    tampilkan(root, 0);
}
