#include "Organisasi.h"

int main() {
    Organisasi hima;
    int pilihan;
    string parent, jabatan;

    do {
        cout << "\nMENU STRUKTUR ORGANISASI HIMA\n";
        cout << "1. Tambah Jabatan\n";
        cout << "2. Tampilkan Struktur\n";
        cout << "3. Keluar\n";
        cout << "Pilih menu: ";
        cin >> pilihan;
        cin.ignore();

        if (pilihan == 1) {
            cout << "Masukkan nama parent (kosongkan jika root): ";
            getline(cin, parent);

            cout << "Masukkan nama jabatan: ";
            getline(cin, jabatan);

            hima.tambahJabatan(parent, jabatan);
        }
        else if (pilihan == 2) {
            cout << "\nSTRUKTUR ORGANISASI:\n";
            hima.tampilStruktur();
        }

    } while (pilihan != 3);

    cout << "Program selesai.\n";
    return 0;
}
